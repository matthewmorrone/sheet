<?php
interface Service_Interface
{
    public function __construct(Service_Messenger $messenger);
}