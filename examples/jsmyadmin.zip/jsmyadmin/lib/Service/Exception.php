<?php
class Service_Exception extends Exception
{

}