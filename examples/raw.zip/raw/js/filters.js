'use strict';

/* Filters */

angular.module('raw.filters', [])