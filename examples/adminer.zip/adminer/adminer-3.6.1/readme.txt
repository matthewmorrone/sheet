Adminer - Database management in single PHP file
Adminer Editor - Data manipulation for end-users

http://www.adminer.org/
Supports: MySQL, PostgreSQL, SQLite, MS SQL, Oracle
Requirements: PHP 4.3.3+ or PHP 5+
Apache License 2.0 or GPL 2

adminer/index.php - Run development version of Adminer
editor/index.php - Run development version of Adminer Editor
editor/example.php - Example customization
plugins/readme.txt - Plugins for Adminer and Adminer Editor
adminer/plugin.php - Plugin demo
compile.php - Create a single file version
lang.php - Update translations
tests/selenium.html - Selenium test suite
